#!/bin/sh

./riscv-jit b2json.bin

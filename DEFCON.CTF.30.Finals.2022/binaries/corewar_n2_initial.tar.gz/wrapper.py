#!/usr/bin/env python3

import sys
import os
import tempfile
import shutil

import subprocess


def fight(data: bytes):
    with tempfile.TemporaryDirectory(dir="/var/tmp/corewar_n2") as td:
        with open(os.path.join(td, "away.bin"), "wb") as f:
            f.write(data)

        shutil.copyfile("./vm", os.path.join(td, "vm"))
        shutil.copyfile("./home.bin", os.path.join(td, "home.bin"))
        shutil.copyfile("./flag", os.path.join(td, "flag"))
        shutil.copyfile("./libcrypto.so.1.1", os.path.join(td, "libcrypto.so.1.1"))
        os.chmod(os.path.join(td, "vm"), 0o777)

        env = dict(os.environ)
        env['LD_LIBRARY_PATH'] = td
        proc = subprocess.Popen(["./vm", "1337", "home.bin", "away.bin"],
                                cwd=td,
                                env=env)
        proc.communicate()


def main():
    size = input("How many bytes are you sending? ")
    try:
        size = int(size)
    except ValueError:
        print("Oops...")
        return

    data = b''
    while len(data) < size:
        delta = sys.stdin.buffer.read(1)
        if not delta:
            break
        data += delta

    if len(data) < size:
        print(f"Expecting {size} bytes, receiving {len(data)} bytes...")
        return

    fight(data)


if __name__ == "__main__":
    main()

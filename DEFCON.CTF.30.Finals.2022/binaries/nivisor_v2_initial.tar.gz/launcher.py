#!/usr/bin/env python3

import os
import sys
import json

NIVISOR_TIMEOUT = "15"
TMP_PATH = "/var/tmp/nivisor"
ROOT_LEAF = "root"
UNTAR_LEAF = "untar"

def main(argc, argv):

    runc_path = "./runc"
    if argc > 1:
        runc_path = argv[1]

    token = input("Token? > ")

    if "." in token:
        print("Bad token")
        sys.exit(-1)

    root_path = os.path.join(TMP_PATH, token, ROOT_LEAF)

    index_path = os.path.join(TMP_PATH, token, UNTAR_LEAF, "index.json")

    if not os.path.exists(index_path):
        print("Invalid token")
        sys.exit(-1)

    if not os.path.exists(root_path):
        print("Image was never unpacked!")
        sys.exit(-1)

    index = {}
    with open(index_path, "rb") as f:
        data = f.read()
        index = json.loads(data.split(b"\x00")[0])

    if not 'nciManifest' in index:
        print("Invalid index.json")
        sys.exit(-1)

    if not 'digest' in index['nciManifest']:
        print("Invalid index.json")
        sys.exit(-1)

    config_digest = index['nciManifest']['digest'].split(":")[1]

    config_path = os.path.join(TMP_PATH,
                               token,
                               UNTAR_LEAF,
                               "blobs",
                               "sha1",
                               config_digest)

    print(config_path)

    if not os.path.exists(config_path):
        print("No config")
        sys.exit(-1)

    config = {}
    with open(config_path, "rb") as f:
        data = f.read()
        config = json.loads(data.split(b"\x00")[0])

    if not 'nciConfig' in config:
        print("Invalid config: no nciConfig")
        sys.exit(-1)

    if not 'digest' in config['nciConfig']:
        print("Invalid config: no digest")
        sys.exit(-1)

    image_config_digest = config['nciConfig']['digest'].split(":")[1]

    image_config_path = os.path.join(TMP_PATH,
                                     token,
                                     UNTAR_LEAF,
                                     "blobs",
                                     "sha1",
                                     image_config_digest)

    if not os.path.exists(image_config_path):
        print("No image config")
        sys.exit(-1)

    image_config = {}
    with open(image_config_path, "rb") as f:
        data = f.read()
        image_config = json.loads(data.split(b"\x00")[0])

    if not 'config' in image_config:
        print("Invalid image config")
        sys.exit(-1)

    runtime_config = image_config['config']

    if not 'EntryPoint' in runtime_config:
        print("Invalid runtime config")
        sys.exit(-1)

    if not 'Cmd' in runtime_config:
        print("Invalid runtime config")
        sys.exit(-1)

    entrypoint = runtime_config['EntryPoint']
    cmd = runtime_config['Cmd']

    timeout_prefix = ["/usr/bin/timeout",
                      "-k",
                      "3",
                      NIVISOR_TIMEOUT]

    args = [runc_path,
            root_path,
            entrypoint]

    args += cmd

    args = timeout_prefix + args

    print(args)

    os.execve(args[0], args, {})

if __name__ == '__main__':
    main(len(sys.argv), sys.argv)

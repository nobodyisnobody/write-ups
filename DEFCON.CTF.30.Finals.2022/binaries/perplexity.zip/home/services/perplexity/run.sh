#!/bin/bash
LD_LIBRARY_PATH=. ./perplexity

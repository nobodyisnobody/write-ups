#!/bin/bash

exec 2>/dev/null
timeout 10 /home/asianparent/chall